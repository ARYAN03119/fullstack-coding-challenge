# Store Rating Platform — Backend

Express.js + PostgreSQL REST API for the FullStack Intern Coding Challenge.

## Tech Stack
- Node.js / Express.js
- PostgreSQL (via `pg`)
- JWT authentication (`jsonwebtoken`)
- Password hashing (`bcryptjs`)
- Request validation (`express-validator`)

## Setup

### 1. Install dependencies
```bash
cd backend
npm install
```

### 2. Configure environment variables
Copy `.env.example` to `.env` and fill in your PostgreSQL credentials:
```bash
cp .env.example .env
```

### 3. Create the database
Create an empty PostgreSQL database matching `DB_NAME` in your `.env` (default: `store_rating_db`):
```sql
CREATE DATABASE store_rating_db;
```

### 4. Run the schema + seed a default admin
```bash
npm run seed
```
This creates all tables (`users`, `stores`, `ratings`) and a default System Administrator account using the credentials in your `.env` (`DEFAULT_ADMIN_EMAIL` / `DEFAULT_ADMIN_PASSWORD`). Use this account to log in initially and create additional users (including Store Owners) from the admin panel.

### 5. Start the server
```bash
npm run dev     # with auto-reload (nodemon)
# or
npm start        # plain node
```

The API will be available at `http://localhost:5000/api`.

## API Overview

| Area | Method | Endpoint | Role |
|---|---|---|---|
| Auth | POST | `/api/auth/signup` | Public (creates Normal User) |
| Auth | POST | `/api/auth/login` | Public |
| Auth | PUT | `/api/auth/update-password` | Any logged-in role |
| Auth | GET | `/api/auth/me` | Any logged-in role |
| Admin | GET | `/api/admin/dashboard` | Admin |
| Admin | POST | `/api/admin/users` | Admin |
| Admin | GET | `/api/admin/users` | Admin (supports `?name=&email=&address=&role=&sortBy=&order=`) |
| Admin | GET | `/api/admin/users/:id` | Admin |
| Admin | POST | `/api/admin/stores` | Admin |
| Admin | GET | `/api/admin/stores` | Admin (supports `?name=&email=&address=&sortBy=&order=`) |
| Admin | GET | `/api/admin/store-owners` | Admin (helper for dropdown) |
| Stores | GET | `/api/stores` | Normal User (supports `?name=&address=&sortBy=&order=`) |
| Stores | POST/PUT | `/api/stores/:storeId/ratings` | Normal User (submit or modify rating) |
| Store Owner | GET | `/api/store-owner/dashboard` | Store Owner |

## Notes on Design Decisions
- **Single `users` table with a `role` column** rather than separate tables per role — this matches the spec's "single login system" requirement and keeps the schema simple while still supporting role-specific behavior in the application layer.
- **`ratings` table has a `UNIQUE (user_id, store_id)` constraint** combined with `INSERT ... ON CONFLICT DO UPDATE`, so "submit a rating" and "modify a rating" are the same database operation — exactly matching the spec's description of both actions.
- **All listing endpoints support filtering and sorting via query parameters**, with sort columns whitelisted server-side to prevent SQL injection through the `sortBy` parameter.
