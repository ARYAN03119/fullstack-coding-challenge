const bcrypt = require('bcryptjs');
const pool = require('../config/db');

// GET /api/admin/dashboard
// Spec: dashboard showing total users, total stores, total ratings submitted.
const getDashboardStats = async (req, res) => {
  try {
    const [usersCount, storesCount, ratingsCount] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM users'),
      pool.query('SELECT COUNT(*) FROM stores'),
      pool.query('SELECT COUNT(*) FROM ratings'),
    ]);

    res.status(200).json({
      totalUsers: parseInt(usersCount.rows[0].count, 10),
      totalStores: parseInt(storesCount.rows[0].count, 10),
      totalRatings: parseInt(ratingsCount.rows[0].count, 10),
    });
  } catch (err) {
    console.error('Dashboard stats error:', err);
    res.status(500).json({ message: 'Something went wrong while fetching dashboard stats.' });
  }
};

// POST /api/admin/users
// Spec: admin "can add new stores, normal users, and admin users" with Name, Email, Password, Address.
// role is passed in the body so the same endpoint can create NORMAL_USER, ADMIN, or STORE_OWNER.
const createUser = async (req, res) => {
  const { name, email, address, password, role } = req.body;
  const allowedRoles = ['ADMIN', 'NORMAL_USER', 'STORE_OWNER'];

  if (!allowedRoles.includes(role)) {
    return res.status(400).json({ message: 'Role must be one of ADMIN, NORMAL_USER, or STORE_OWNER.' });
  }

  try {
    const existing = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ message: 'A user with this email already exists.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await pool.query(
      `INSERT INTO users (name, email, password, address, role)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, name, email, address, role, created_at`,
      [name, email, hashedPassword, address, role]
    );

    res.status(201).json({ message: 'User created successfully.', user: result.rows[0] });
  } catch (err) {
    console.error('Create user error:', err);
    res.status(500).json({ message: 'Something went wrong while creating the user.' });
  }
};

// POST /api/admin/stores
// Spec: admin can add new stores. A store can optionally be linked to a STORE_OWNER account
// so that owner can see their own dashboard (list of raters + average rating).
const createStore = async (req, res) => {
  const { name, email, address, ownerId } = req.body;

  try {
    if (ownerId) {
      const owner = await pool.query('SELECT id, role FROM users WHERE id = $1', [ownerId]);
      if (owner.rows.length === 0) {
        return res.status(404).json({ message: 'Specified store owner does not exist.' });
      }
      if (owner.rows[0].role !== 'STORE_OWNER') {
        return res.status(400).json({ message: 'Specified user is not a Store Owner.' });
      }
    }

    const existing = await pool.query('SELECT id FROM stores WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ message: 'A store with this email already exists.' });
    }

    const result = await pool.query(
      `INSERT INTO stores (name, email, address, owner_id)
       VALUES ($1, $2, $3, $4)
       RETURNING id, name, email, address, owner_id, created_at`,
      [name, email, address, ownerId || null]
    );

    res.status(201).json({ message: 'Store created successfully.', store: result.rows[0] });
  } catch (err) {
    console.error('Create store error:', err);
    res.status(500).json({ message: 'Something went wrong while creating the store.' });
  }
};

// GET /api/admin/stores?name=&email=&address=&sortBy=&order=
// Spec: list of stores with Name, Email, Address, Rating + filters + sorting.
const getAllStoresForAdmin = async (req, res) => {
  const { name, email, address, sortBy = 'name', order = 'asc' } = req.query;

  const allowedSortColumns = ['name', 'email', 'address', 'rating'];
  const allowedOrder = ['asc', 'desc'];
  const safeSortBy = allowedSortColumns.includes(sortBy) ? sortBy : 'name';
  const safeOrder = allowedOrder.includes(order.toLowerCase()) ? order.toUpperCase() : 'ASC';

  try {
    const conditions = [];
    const values = [];
    let idx = 1;

    if (name) {
      conditions.push(`s.name ILIKE $${idx++}`);
      values.push(`%${name}%`);
    }
    if (email) {
      conditions.push(`s.email ILIKE $${idx++}`);
      values.push(`%${email}%`);
    }
    if (address) {
      conditions.push(`s.address ILIKE $${idx++}`);
      values.push(`%${address}%`);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    // rating is an aggregate so it needs its own ORDER BY column reference
    const orderColumn = safeSortBy === 'rating' ? 'rating' : `s.${safeSortBy}`;

    const query = `
      SELECT s.id, s.name, s.email, s.address,
             COALESCE(ROUND(AVG(r.rating)::numeric, 2), 0) AS rating,
             COUNT(r.id) AS total_ratings
      FROM stores s
      LEFT JOIN ratings r ON r.store_id = s.id
      ${whereClause}
      GROUP BY s.id
      ORDER BY ${orderColumn} ${safeOrder}
    `;

    const result = await pool.query(query, values);
    res.status(200).json({ stores: result.rows });
  } catch (err) {
    console.error('Get stores (admin) error:', err);
    res.status(500).json({ message: 'Something went wrong while fetching stores.' });
  }
};

// GET /api/admin/users?name=&email=&address=&role=&sortBy=&order=
// Spec: list of normal and admin users with Name, Email, Address, Role + filters + sorting.
// (Store owners are included too so the admin has one place to see everyone; role filter handles narrowing.)
const getAllUsers = async (req, res) => {
  const { name, email, address, role, sortBy = 'name', order = 'asc' } = req.query;

  const allowedSortColumns = ['name', 'email', 'address', 'role'];
  const allowedOrder = ['asc', 'desc'];
  const safeSortBy = allowedSortColumns.includes(sortBy) ? sortBy : 'name';
  const safeOrder = allowedOrder.includes(order.toLowerCase()) ? order.toUpperCase() : 'ASC';

  try {
    const conditions = [];
    const values = [];
    let idx = 1;

    if (name) {
      conditions.push(`name ILIKE $${idx++}`);
      values.push(`%${name}%`);
    }
    if (email) {
      conditions.push(`email ILIKE $${idx++}`);
      values.push(`%${email}%`);
    }
    if (address) {
      conditions.push(`address ILIKE $${idx++}`);
      values.push(`%${address}%`);
    }
    if (role) {
      conditions.push(`role = $${idx++}`);
      values.push(role);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const query = `
      SELECT id, name, email, address, role, created_at
      FROM users
      ${whereClause}
      ORDER BY ${safeSortBy} ${safeOrder}
    `;

    const result = await pool.query(query, values);
    res.status(200).json({ users: result.rows });
  } catch (err) {
    console.error('Get users error:', err);
    res.status(500).json({ message: 'Something went wrong while fetching users.' });
  }
};

// GET /api/admin/users/:id
// Spec: view details of all users (Name, Email, Address, Role); if Store Owner, also show their Rating.
const getUserDetails = async (req, res) => {
  const { id } = req.params;

  try {
    const userResult = await pool.query(
      'SELECT id, name, email, address, role, created_at FROM users WHERE id = $1',
      [id]
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({ message: 'User not found.' });
    }

    const user = userResult.rows[0];

    if (user.role === 'STORE_OWNER') {
      const ratingResult = await pool.query(
        `SELECT COALESCE(ROUND(AVG(r.rating)::numeric, 2), 0) AS rating, COUNT(r.id) AS total_ratings
         FROM stores s
         LEFT JOIN ratings r ON r.store_id = s.id
         WHERE s.owner_id = $1`,
        [id]
      );
      user.storeRating = ratingResult.rows[0].rating;
      user.totalRatings = parseInt(ratingResult.rows[0].total_ratings, 10);
    }

    res.status(200).json({ user });
  } catch (err) {
    console.error('Get user details error:', err);
    res.status(500).json({ message: 'Something went wrong while fetching user details.' });
  }
};

// GET /api/admin/store-owners
// Helper endpoint for the "add store" form, to populate a dropdown of available store owners.
const getStoreOwners = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, email FROM users WHERE role = 'STORE_OWNER' ORDER BY name ASC`
    );
    res.status(200).json({ storeOwners: result.rows });
  } catch (err) {
    console.error('Get store owners error:', err);
    res.status(500).json({ message: 'Something went wrong while fetching store owners.' });
  }
};

module.exports = {
  getDashboardStats,
  createUser,
  createStore,
  getAllStoresForAdmin,
  getAllUsers,
  getUserDetails,
  getStoreOwners,
};
