const pool = require('../config/db');

// GET /api/store-owner/dashboard
// Spec: Store Owner dashboard - list of users who rated their store, and the average rating.
// Looks up the store(s) owned by the logged-in user via stores.owner_id.
const getStoreOwnerDashboard = async (req, res) => {
  const ownerId = req.user.id;

  try {
    const storeResult = await pool.query('SELECT id, name, email, address FROM stores WHERE owner_id = $1', [ownerId]);

    if (storeResult.rows.length === 0) {
      return res.status(404).json({ message: 'No store is currently linked to your account. Please contact an administrator.' });
    }

    // Spec describes a single store-owner dashboard; supporting multiple stores per owner
    // just in case, but typically this array will have one entry.
    const stores = await Promise.all(
      storeResult.rows.map(async (store) => {
        const ratersResult = await pool.query(
          `SELECT u.id AS user_id, u.name, u.email, r.rating, r.updated_at
           FROM ratings r
           JOIN users u ON u.id = r.user_id
           WHERE r.store_id = $1
           ORDER BY r.updated_at DESC`,
          [store.id]
        );

        const avgResult = await pool.query(
          `SELECT COALESCE(ROUND(AVG(rating)::numeric, 2), 0) AS average_rating, COUNT(*) AS total_ratings
           FROM ratings WHERE store_id = $1`,
          [store.id]
        );

        return {
          store,
          averageRating: avgResult.rows[0].average_rating,
          totalRatings: parseInt(avgResult.rows[0].total_ratings, 10),
          raters: ratersResult.rows,
        };
      })
    );

    res.status(200).json({ stores });
  } catch (err) {
    console.error('Store owner dashboard error:', err);
    res.status(500).json({ message: 'Something went wrong while loading your dashboard.' });
  }
};

module.exports = { getStoreOwnerDashboard };
