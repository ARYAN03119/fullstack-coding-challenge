const pool = require('../config/db');

// GET /api/stores?name=&address=&sortBy=&order=
// Spec: normal user can view all stores, search by Name and Address, see Store Name, Address,
// Overall Rating, and their own submitted rating for each store.
const getStoresForUser = async (req, res) => {
  const { name, address, sortBy = 'name', order = 'asc' } = req.query;
  const userId = req.user.id;

  const allowedSortColumns = ['name', 'address', 'overall_rating'];
  const allowedOrder = ['asc', 'desc'];
  const safeSortBy = allowedSortColumns.includes(sortBy) ? sortBy : 'name';
  const safeOrder = allowedOrder.includes(order.toLowerCase()) ? order.toUpperCase() : 'ASC';

  try {
    const conditions = [];
    const values = [userId];
    let idx = 2; // $1 is reserved for userId in the subquery below

    if (name) {
      conditions.push(`s.name ILIKE $${idx++}`);
      values.push(`%${name}%`);
    }
    if (address) {
      conditions.push(`s.address ILIKE $${idx++}`);
      values.push(`%${address}%`);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const query = `
      SELECT
        s.id,
        s.name,
        s.address,
        COALESCE(ROUND(AVG(r.rating)::numeric, 2), 0) AS overall_rating,
        COUNT(r.id) AS total_ratings,
        ur.rating AS user_rating
      FROM stores s
      LEFT JOIN ratings r ON r.store_id = s.id
      LEFT JOIN ratings ur ON ur.store_id = s.id AND ur.user_id = $1
      ${whereClause}
      GROUP BY s.id, ur.rating
      ORDER BY ${safeSortBy === 'overall_rating' ? 'overall_rating' : `s.${safeSortBy}`} ${safeOrder}
    `;

    const result = await pool.query(query, values);
    res.status(200).json({ stores: result.rows });
  } catch (err) {
    console.error('Get stores (user) error:', err);
    res.status(500).json({ message: 'Something went wrong while fetching stores.' });
  }
};

// POST /api/stores/:storeId/ratings
// PUT (same handler) - Spec: "submit ratings" and "modify their submitted rating" (1 to 5).
// Uses ON CONFLICT so the very first submission inserts and any later one updates -
// this is what makes "submit" and "modify" the same operation under the hood.
const submitOrUpdateRating = async (req, res) => {
  const { storeId } = req.params;
  const { rating } = req.body;
  const userId = req.user.id;

  try {
    const store = await pool.query('SELECT id FROM stores WHERE id = $1', [storeId]);
    if (store.rows.length === 0) {
      return res.status(404).json({ message: 'Store not found.' });
    }

    const result = await pool.query(
      `INSERT INTO ratings (user_id, store_id, rating)
       VALUES ($1, $2, $3)
       ON CONFLICT (user_id, store_id)
       DO UPDATE SET rating = EXCLUDED.rating, updated_at = NOW()
       RETURNING id, user_id, store_id, rating, updated_at`,
      [userId, storeId, rating]
    );

    res.status(200).json({ message: 'Rating submitted successfully.', rating: result.rows[0] });
  } catch (err) {
    console.error('Submit rating error:', err);
    res.status(500).json({ message: 'Something went wrong while submitting your rating.' });
  }
};

module.exports = { getStoresForUser, submitOrUpdateRating };
