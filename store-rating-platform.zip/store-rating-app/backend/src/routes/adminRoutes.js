const express = require('express');
const router = express.Router();
const {
  getDashboardStats,
  createUser,
  createStore,
  getAllStoresForAdmin,
  getAllUsers,
  getUserDetails,
  getStoreOwners,
} = require('../controllers/adminController');
const { authenticate, authorize } = require('../middleware/auth');
const { signupValidationRules, storeValidationRules, validate } = require('../validators/validators');

// Every route below is admin-only
router.use(authenticate, authorize('ADMIN'));

router.get('/dashboard', getDashboardStats);

router.post('/users', signupValidationRules, validate, createUser);
router.get('/users', getAllUsers);
router.get('/users/:id', getUserDetails);

router.post('/stores', storeValidationRules, validate, createStore);
router.get('/stores', getAllStoresForAdmin);

router.get('/store-owners', getStoreOwners);

module.exports = router;
