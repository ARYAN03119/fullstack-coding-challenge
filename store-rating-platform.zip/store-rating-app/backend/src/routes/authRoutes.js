const express = require('express');
const router = express.Router();
const { signup, login, updatePassword, getCurrentUser } = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');
const {
  signupValidationRules,
  loginValidationRules,
  updatePasswordValidationRules,
  validate,
} = require('../validators/validators');

router.post('/signup', signupValidationRules, validate, signup);
router.post('/login', loginValidationRules, validate, login);
router.put('/update-password', authenticate, updatePasswordValidationRules, validate, updatePassword);
router.get('/me', authenticate, getCurrentUser);

module.exports = router;
