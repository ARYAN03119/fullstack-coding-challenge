const express = require('express');
const router = express.Router();
const { getStoreOwnerDashboard } = require('../controllers/storeOwnerController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/dashboard', authenticate, authorize('STORE_OWNER'), getStoreOwnerDashboard);

module.exports = router;
