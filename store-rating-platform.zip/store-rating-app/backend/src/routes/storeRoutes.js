const express = require('express');
const router = express.Router();
const { getStoresForUser, submitOrUpdateRating } = require('../controllers/userController');
const { authenticate, authorize } = require('../middleware/auth');
const { ratingRule, validate } = require('../validators/validators');

// Normal users browse stores and rate them
router.get('/', authenticate, authorize('NORMAL_USER'), getStoresForUser);
router.post('/:storeId/ratings', authenticate, authorize('NORMAL_USER'), ratingRule, validate, submitOrUpdateRating);
router.put('/:storeId/ratings', authenticate, authorize('NORMAL_USER'), ratingRule, validate, submitOrUpdateRating);

module.exports = router;
