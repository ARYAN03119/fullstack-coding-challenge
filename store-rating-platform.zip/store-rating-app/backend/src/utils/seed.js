require('dotenv').config();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const pool = require('../config/db');

const run = async () => {
  try {
    console.log('Running schema.sql ...');
    const schemaPath = path.join(__dirname, '../config/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    await pool.query(schema);
    console.log('Schema applied.');

    const adminEmail = process.env.DEFAULT_ADMIN_EMAIL;
    const existing = await pool.query('SELECT id FROM users WHERE email = $1', [adminEmail]);

    if (existing.rows.length > 0) {
      console.log('Default admin already exists, skipping creation.');
    } else {
      const hashedPassword = await bcrypt.hash(process.env.DEFAULT_ADMIN_PASSWORD, 10);
      await pool.query(
        `INSERT INTO users (name, email, password, address, role)
         VALUES ($1, $2, $3, $4, 'ADMIN')`,
        [
          process.env.DEFAULT_ADMIN_NAME,
          adminEmail,
          hashedPassword,
          process.env.DEFAULT_ADMIN_ADDRESS,
        ]
      );
      console.log(`Default admin created: ${adminEmail} / ${process.env.DEFAULT_ADMIN_PASSWORD}`);
    }

    console.log('Seed complete.');
    process.exit(0);
  } catch (err) {
    console.error('Seed failed:', err);
    process.exit(1);
  }
};

run();
