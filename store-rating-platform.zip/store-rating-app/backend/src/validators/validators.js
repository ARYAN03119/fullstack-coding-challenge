const { body, validationResult } = require('express-validator');

// Spec: Name Min 20, Max 60 characters.
const nameRule = body('name')
  .trim()
  .isLength({ min: 20, max: 60 })
  .withMessage('Name must be between 20 and 60 characters.');

// Spec: Address Max 400 characters.
const addressRule = body('address')
  .trim()
  .isLength({ min: 1, max: 400 })
  .withMessage('Address is required and must be at most 400 characters.');

// Spec: Password 8-16 characters, at least one uppercase letter and one special character.
const passwordRule = body('password')
  .isLength({ min: 8, max: 16 })
  .withMessage('Password must be between 8 and 16 characters.')
  .matches(/[A-Z]/)
  .withMessage('Password must contain at least one uppercase letter.')
  .matches(/[!@#$%^&*(),.?":{}|<>_\-+=~`[\]\\/;']/)
  .withMessage('Password must contain at least one special character.');

// Spec: Email must follow standard email validation rules.
const emailRule = body('email')
  .trim()
  .isEmail()
  .withMessage('Please provide a valid email address.')
  .normalizeEmail();

const ratingRule = body('rating')
  .isInt({ min: 1, max: 5 })
  .withMessage('Rating must be an integer between 1 and 5.');

// Used on signup (normal user) and on admin "add user" form
const signupValidationRules = [nameRule, emailRule, addressRule, passwordRule];

// Used on admin "add store" form
const storeValidationRules = [
  nameRule,
  emailRule,
  addressRule,
];

const loginValidationRules = [
  body('email').trim().isEmail().withMessage('Please provide a valid email address.'),
  body('password').notEmpty().withMessage('Password is required.'),
];

const updatePasswordValidationRules = [
  body('oldPassword').notEmpty().withMessage('Current password is required.'),
  passwordRule.withMessage('New password must be 8-16 characters, with at least one uppercase letter and one special character.'),
];

// Middleware that runs after the rule arrays above and turns any failures into a 400 response
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      message: 'Validation failed',
      errors: errors.array().map((e) => ({ field: e.path, message: e.msg })),
    });
  }
  next();
};

module.exports = {
  nameRule,
  addressRule,
  passwordRule,
  emailRule,
  ratingRule,
  signupValidationRules,
  storeValidationRules,
  loginValidationRules,
  updatePasswordValidationRules,
  validate,
};
