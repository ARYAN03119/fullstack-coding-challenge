# Store Rating Platform — Frontend

React (Vite) frontend for the FullStack Intern Coding Challenge.

## Tech Stack
- React 19
- React Router v7
- Axios
- Plain CSS (no UI framework, kept intentionally simple and dependency-light)

## Setup

### 1. Install dependencies
```bash
cd frontend
npm install
```

### 2. Configure the API URL
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
By default this points to `http://localhost:5000/api`, matching the backend's default port.

### 3. Start the dev server
```bash
npm run dev
```
The app will be available at `http://localhost:5173`.

### 4. Build for production
```bash
npm run build
```
Output goes to `dist/`.

## Structure
```
src/
├── api/             # Axios instance + one file per feature area (auth, admin, user, store owner)
├── components/       # Shared UI: Navbar, ProtectedRoute, StarRating, SortableHeader
├── context/           # AuthProvider + useAuth hook (JWT session state)
├── pages/
│   ├── auth/          # Login, Signup
│   ├── admin/         # Dashboard, Users, Stores
│   ├── user/           # Browse/search/rate stores
│   └── storeOwner/     # Dashboard with raters + average rating
└── App.jsx            # Routes, role-based guards
```

## How role-based routing works
- After login, the JWT and user object (including `role`) are stored in `localStorage`.
- `ProtectedRoute` checks both "is anyone logged in" and, if `allowedRoles` is passed, whether the current user's role is permitted — redirecting to `/login` or `/unauthorized` otherwise.
- The root path `/` auto-redirects to the correct dashboard based on role (`/admin/dashboard`, `/user/stores`, or `/owner/dashboard`).

## Validation
Signup form validation (name length, password complexity, etc.) mirrors the backend's `express-validator` rules exactly, so users get instant feedback without waiting on a round trip — but the backend re-validates everything independently, since client-side checks can always be bypassed.
