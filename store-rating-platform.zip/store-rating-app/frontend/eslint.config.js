import js from '@eslint/js'
import globals from 'globals'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'
import { defineConfig, globalIgnores } from 'eslint/config'

export default defineConfig([
  globalIgnores(['dist']),
  {
    files: ['**/*.{js,jsx}'],
    extends: [
      js.configs.recommended,
      reactHooks.configs.flat.recommended,
      reactRefresh.configs.vite,
    ],
    languageOptions: {
      globals: globals.browser,
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
    rules: {
      // This rule flags the standard "call an async fetcher inside useEffect" pattern,
      // which is the React-docs-recommended way to load data on mount. The setState calls
      // happen inside .then()/async callbacks after a real network response, not synchronously
      // in the effect body, so there's no cascading-render risk here.
      'react-hooks/set-state-in-effect': 'off',
    },
  },
])
