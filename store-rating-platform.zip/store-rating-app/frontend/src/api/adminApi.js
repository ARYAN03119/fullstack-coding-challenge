import axiosClient from './axiosClient';

export const getDashboardStatsApi = () => axiosClient.get('/admin/dashboard');

export const createUserApi = (data) => axiosClient.post('/admin/users', data);
export const getAllUsersApi = (params) => axiosClient.get('/admin/users', { params });
export const getUserDetailsApi = (id) => axiosClient.get(`/admin/users/${id}`);

export const createStoreApi = (data) => axiosClient.post('/admin/stores', data);
export const getAllStoresAdminApi = (params) => axiosClient.get('/admin/stores', { params });

export const getStoreOwnersApi = () => axiosClient.get('/admin/store-owners');
