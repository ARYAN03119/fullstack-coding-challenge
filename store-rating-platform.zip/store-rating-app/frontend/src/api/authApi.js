import axiosClient from './axiosClient';

export const signupApi = (data) => axiosClient.post('/auth/signup', data);
export const loginApi = (data) => axiosClient.post('/auth/login', data);
export const updatePasswordApi = (data) => axiosClient.put('/auth/update-password', data);
export const getCurrentUserApi = () => axiosClient.get('/auth/me');
