import axiosClient from './axiosClient';

export const getStoreOwnerDashboardApi = () => axiosClient.get('/store-owner/dashboard');
