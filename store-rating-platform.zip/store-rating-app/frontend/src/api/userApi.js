import axiosClient from './axiosClient';

export const getStoresApi = (params) => axiosClient.get('/stores', { params });
export const submitRatingApi = (storeId, rating) =>
  axiosClient.post(`/stores/${storeId}/ratings`, { rating });
