import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/useAuth';

const roleLabels = {
  ADMIN: 'System Administrator',
  NORMAL_USER: 'User',
  STORE_OWNER: 'Store Owner',
};

const roleHome = {
  ADMIN: '/admin/dashboard',
  NORMAL_USER: '/user/stores',
  STORE_OWNER: '/owner/dashboard',
};

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <Link to={roleHome[user.role]} className="navbar-brand">
        Store Rating Platform
      </Link>
      <div className="navbar-right">
        <span className="navbar-user">
          {user.name} <span className="navbar-role">({roleLabels[user.role]})</span>
        </span>
        <Link to="/update-password" className="navbar-link">
          Update Password
        </Link>
        <button onClick={handleLogout} className="navbar-logout-btn">
          Logout
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
