import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/useAuth';

// Wrap any page with this to require login, and optionally restrict to specific roles.
// Usage: <ProtectedRoute allowedRoles={['ADMIN']}><AdminDashboard /></ProtectedRoute>
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="page-loading">Loading...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return children;
};

export default ProtectedRoute;
