// A <th> that toggles asc/desc sort on click and shows an arrow for the active column.
// sortBy/order/onSort are lifted up to the parent page, which re-fetches data with new params.
const SortableHeader = ({ label, field, sortBy, order, onSort }) => {
  const isActive = sortBy === field;

  const handleClick = () => {
    if (isActive) {
      onSort(field, order === 'asc' ? 'desc' : 'asc');
    } else {
      onSort(field, 'asc');
    }
  };

  return (
    <th onClick={handleClick} className="sortable-header">
      {label} {isActive ? (order === 'asc' ? '▲' : '▼') : ''}
    </th>
  );
};

export default SortableHeader;
