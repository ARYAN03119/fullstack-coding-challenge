import { useState } from 'react';

// Interactive 1-5 star picker. `value` is the currently selected rating (or null).
// onChange receives the chosen integer 1-5.
const StarRating = ({ value, onChange, disabled }) => {
  const [hovered, setHovered] = useState(null);

  const displayValue = hovered ?? value ?? 0;

  return (
    <div className="star-rating" aria-label={`Rating: ${value || 'not rated'} out of 5`}>
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          disabled={disabled}
          className={`star-btn ${star <= displayValue ? 'star-filled' : ''}`}
          onMouseEnter={() => !disabled && setHovered(star)}
          onMouseLeave={() => !disabled && setHovered(null)}
          onClick={() => !disabled && onChange(star)}
          aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
        >
          ★
        </button>
      ))}
    </div>
  );
};

export default StarRating;
