import { Link } from 'react-router-dom';

const Unauthorized = () => (
  <div className="page-container centered-message">
    <h1>403 - Access Denied</h1>
    <p>You don't have permission to view this page.</p>
    <Link to="/login">Back to Login</Link>
  </div>
);

export default Unauthorized;
