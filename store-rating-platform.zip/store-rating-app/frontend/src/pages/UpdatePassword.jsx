import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { updatePasswordApi } from '../api/authApi';
import Navbar from '../components/Navbar';

const UpdatePassword = () => {
  const [form, setForm] = useState({ oldPassword: '', password: '', confirmPassword: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (form.password !== form.confirmPassword) {
      setError('New password and confirmation do not match.');
      return;
    }

    setSubmitting(true);
    try {
      await updatePasswordApi({ oldPassword: form.oldPassword, password: form.password });
      setSuccess('Password updated successfully.');
      setForm({ oldPassword: '', password: '', confirmPassword: '' });
    } catch (err) {
      const errors = err.response?.data?.errors;
      setError(errors ? errors.map((e) => e.message).join(' ') : err.response?.data?.message || 'Failed to update password.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <Navbar />
      <div className="page-container">
        <div className="card narrow-card">
          <h2>Update Password</h2>
          <form onSubmit={handleSubmit} className="stacked-form">
            {error && <div className="form-error">{error}</div>}
            {success && <div className="form-success">{success}</div>}

            <label>
              Current Password
              <input type="password" name="oldPassword" value={form.oldPassword} onChange={handleChange} required />
            </label>

            <label>
              New Password
              <input type="password" name="password" value={form.password} onChange={handleChange} required />
              <span className="field-hint">8-16 characters, 1 uppercase letter, 1 special character</span>
            </label>

            <label>
              Confirm New Password
              <input type="password" name="confirmPassword" value={form.confirmPassword} onChange={handleChange} required />
            </label>

            <div className="form-actions">
              <button type="button" className="secondary-btn" onClick={() => navigate(-1)}>
                Back
              </button>
              <button type="submit" disabled={submitting}>
                {submitting ? 'Updating...' : 'Update Password'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default UpdatePassword;
