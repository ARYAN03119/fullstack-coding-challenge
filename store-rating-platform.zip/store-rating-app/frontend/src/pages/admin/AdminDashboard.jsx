import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getDashboardStatsApi } from '../../api/adminApi';
import Navbar from '../../components/Navbar';

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    getDashboardStatsApi()
      .then((res) => setStats(res.data))
      .catch(() => setError('Failed to load dashboard stats.'));
  }, []);

  return (
    <>
      <Navbar />
      <div className="page-container">
        <h1>Admin Dashboard</h1>

        {error && <div className="form-error">{error}</div>}

        {stats && (
          <div className="stats-grid">
            <div className="stat-card">
              <span className="stat-number">{stats.totalUsers}</span>
              <span className="stat-label">Total Users</span>
            </div>
            <div className="stat-card">
              <span className="stat-number">{stats.totalStores}</span>
              <span className="stat-label">Total Stores</span>
            </div>
            <div className="stat-card">
              <span className="stat-number">{stats.totalRatings}</span>
              <span className="stat-label">Total Ratings Submitted</span>
            </div>
          </div>
        )}

        <div className="quick-links">
          <Link to="/admin/users" className="quick-link-card">
            Manage Users →
          </Link>
          <Link to="/admin/stores" className="quick-link-card">
            Manage Stores →
          </Link>
        </div>
      </div>
    </>
  );
};

export default AdminDashboard;
