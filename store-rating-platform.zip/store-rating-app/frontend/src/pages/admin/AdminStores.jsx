import { useState, useEffect, useCallback } from 'react';
import { getAllStoresAdminApi, createStoreApi, getStoreOwnersApi } from '../../api/adminApi';
import Navbar from '../../components/Navbar';
import SortableHeader from '../../components/SortableHeader';

const emptyForm = { name: '', email: '', address: '', ownerId: '' };

const AdminStores = () => {
  const [stores, setStores] = useState([]);
  const [storeOwners, setStoreOwners] = useState([]);
  const [filters, setFilters] = useState({ name: '', email: '', address: '' });
  const [sortBy, setSortBy] = useState('name');
  const [order, setOrder] = useState('asc');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState(emptyForm);
  const [formErrors, setFormErrors] = useState({});
  const [formMessage, setFormMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const fetchStores = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = { ...filters, sortBy, order };
      Object.keys(params).forEach((k) => params[k] === '' && delete params[k]);
      const res = await getAllStoresAdminApi(params);
      setStores(res.data.stores);
    } catch {
      setError('Failed to load stores.');
    } finally {
      setLoading(false);
    }
  }, [filters, sortBy, order]);

  useEffect(() => {
    fetchStores();
  }, [fetchStores]);

  useEffect(() => {
    getStoreOwnersApi()
      .then((res) => setStoreOwners(res.data.storeOwners))
      .catch(() => {
        /* non-critical: owner dropdown just stays empty */
      });
  }, [showAddForm]);

  const handleFilterChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const handleSort = (field, newOrder) => {
    setSortBy(field);
    setOrder(newOrder);
  };

  const handleFormChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleAddStore = async (e) => {
    e.preventDefault();
    setFormErrors({});
    setFormMessage('');
    setSubmitting(true);
    try {
      const payload = { ...formData, ownerId: formData.ownerId || null };
      await createStoreApi(payload);
      setFormMessage('Store created successfully.');
      setFormData(emptyForm);
      fetchStores();
    } catch (err) {
      if (err.response?.data?.errors) {
        const errs = {};
        err.response.data.errors.forEach((e) => (errs[e.field] = e.message));
        setFormErrors(errs);
      } else {
        setFormMessage(err.response?.data?.message || 'Failed to create store.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <Navbar />
      <div className="page-container">
        <div className="page-header-row">
          <h1>Manage Stores</h1>
          <button onClick={() => setShowAddForm(!showAddForm)}>
            {showAddForm ? 'Cancel' : '+ Add Store'}
          </button>
        </div>

        {showAddForm && (
          <div className="card">
            <h3>Add New Store</h3>
            <form onSubmit={handleAddStore} className="inline-form">
              {formMessage && <div className={formErrors && Object.keys(formErrors).length ? 'form-error' : 'form-success'}>{formMessage}</div>}

              <label>
                Store Name
                <input type="text" name="name" value={formData.name} onChange={handleFormChange} required />
                {formErrors.name && <span className="field-error">{formErrors.name}</span>}
              </label>

              <label>
                Store Email
                <input type="email" name="email" value={formData.email} onChange={handleFormChange} required />
                {formErrors.email && <span className="field-error">{formErrors.email}</span>}
              </label>

              <label>
                Address
                <textarea name="address" value={formData.address} onChange={handleFormChange} required rows={2} />
                {formErrors.address && <span className="field-error">{formErrors.address}</span>}
              </label>

              <label>
                Store Owner (optional)
                <select name="ownerId" value={formData.ownerId} onChange={handleFormChange}>
                  <option value="">-- No owner linked yet --</option>
                  {storeOwners.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.name} ({o.email})
                    </option>
                  ))}
                </select>
                <span className="field-hint">
                  Only users created with role "Store Owner" appear here. Create that user first if needed.
                </span>
              </label>

              <button type="submit" disabled={submitting}>
                {submitting ? 'Creating...' : 'Create Store'}
              </button>
            </form>
          </div>
        )}

        <div className="filters-row">
          <input name="name" placeholder="Filter by Name" value={filters.name} onChange={handleFilterChange} />
          <input name="email" placeholder="Filter by Email" value={filters.email} onChange={handleFilterChange} />
          <input name="address" placeholder="Filter by Address" value={filters.address} onChange={handleFilterChange} />
        </div>

        {error && <div className="form-error">{error}</div>}

        {loading ? (
          <p>Loading stores...</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <SortableHeader label="Name" field="name" sortBy={sortBy} order={order} onSort={handleSort} />
                <SortableHeader label="Email" field="email" sortBy={sortBy} order={order} onSort={handleSort} />
                <SortableHeader label="Address" field="address" sortBy={sortBy} order={order} onSort={handleSort} />
                <SortableHeader label="Rating" field="rating" sortBy={sortBy} order={order} onSort={handleSort} />
              </tr>
            </thead>
            <tbody>
              {stores.map((s) => (
                <tr key={s.id}>
                  <td>{s.name}</td>
                  <td>{s.email}</td>
                  <td className="address-cell">{s.address}</td>
                  <td>
                    {s.rating > 0 ? `★ ${s.rating}` : 'No ratings yet'}{' '}
                    <span className="muted-text">({s.total_ratings})</span>
                  </td>
                </tr>
              ))}
              {stores.length === 0 && (
                <tr>
                  <td colSpan={4} className="empty-row">
                    No stores found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
};

export default AdminStores;
