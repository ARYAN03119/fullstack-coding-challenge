import { useState, useEffect, useCallback } from 'react';
import { getAllUsersApi, createUserApi, getUserDetailsApi } from '../../api/adminApi';
import Navbar from '../../components/Navbar';
import SortableHeader from '../../components/SortableHeader';

const emptyForm = { name: '', email: '', address: '', password: '', role: 'NORMAL_USER' };

const AdminUsers = () => {
  const [users, setUsers] = useState([]);
  const [filters, setFilters] = useState({ name: '', email: '', address: '', role: '' });
  const [sortBy, setSortBy] = useState('name');
  const [order, setOrder] = useState('asc');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState(emptyForm);
  const [formErrors, setFormErrors] = useState({});
  const [formMessage, setFormMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [selectedUser, setSelectedUser] = useState(null);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = { ...filters, sortBy, order };
      Object.keys(params).forEach((k) => params[k] === '' && delete params[k]);
      const res = await getAllUsersApi(params);
      setUsers(res.data.users);
    } catch {
      setError('Failed to load users.');
    } finally {
      setLoading(false);
    }
  }, [filters, sortBy, order]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const handleFilterChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const handleSort = (field, newOrder) => {
    setSortBy(field);
    setOrder(newOrder);
  };

  const handleFormChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleAddUser = async (e) => {
    e.preventDefault();
    setFormErrors({});
    setFormMessage('');
    setSubmitting(true);
    try {
      await createUserApi(formData);
      setFormMessage('User created successfully.');
      setFormData(emptyForm);
      fetchUsers();
    } catch (err) {
      if (err.response?.data?.errors) {
        const errs = {};
        err.response.data.errors.forEach((e) => (errs[e.field] = e.message));
        setFormErrors(errs);
      } else {
        setFormMessage(err.response?.data?.message || 'Failed to create user.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleViewDetails = async (id) => {
    try {
      const res = await getUserDetailsApi(id);
      setSelectedUser(res.data.user);
    } catch {
      setError('Failed to load user details.');
    }
  };

  return (
    <>
      <Navbar />
      <div className="page-container">
        <div className="page-header-row">
          <h1>Manage Users</h1>
          <button onClick={() => setShowAddForm(!showAddForm)}>
            {showAddForm ? 'Cancel' : '+ Add User'}
          </button>
        </div>

        {showAddForm && (
          <div className="card">
            <h3>Add New User</h3>
            <form onSubmit={handleAddUser} className="inline-form">
              {formMessage && <div className={formErrors && Object.keys(formErrors).length ? 'form-error' : 'form-success'}>{formMessage}</div>}

              <label>
                Name
                <input type="text" name="name" value={formData.name} onChange={handleFormChange} required />
                {formErrors.name && <span className="field-error">{formErrors.name}</span>}
              </label>

              <label>
                Email
                <input type="email" name="email" value={formData.email} onChange={handleFormChange} required />
                {formErrors.email && <span className="field-error">{formErrors.email}</span>}
              </label>

              <label>
                Address
                <textarea name="address" value={formData.address} onChange={handleFormChange} required rows={2} />
                {formErrors.address && <span className="field-error">{formErrors.address}</span>}
              </label>

              <label>
                Password
                <input type="password" name="password" value={formData.password} onChange={handleFormChange} required />
                {formErrors.password && <span className="field-error">{formErrors.password}</span>}
              </label>

              <label>
                Role
                <select name="role" value={formData.role} onChange={handleFormChange}>
                  <option value="NORMAL_USER">Normal User</option>
                  <option value="ADMIN">System Administrator</option>
                  <option value="STORE_OWNER">Store Owner</option>
                </select>
              </label>

              <button type="submit" disabled={submitting}>
                {submitting ? 'Creating...' : 'Create User'}
              </button>
            </form>
          </div>
        )}

        <div className="filters-row">
          <input name="name" placeholder="Filter by Name" value={filters.name} onChange={handleFilterChange} />
          <input name="email" placeholder="Filter by Email" value={filters.email} onChange={handleFilterChange} />
          <input name="address" placeholder="Filter by Address" value={filters.address} onChange={handleFilterChange} />
          <select name="role" value={filters.role} onChange={handleFilterChange}>
            <option value="">All Roles</option>
            <option value="NORMAL_USER">Normal User</option>
            <option value="ADMIN">System Administrator</option>
            <option value="STORE_OWNER">Store Owner</option>
          </select>
        </div>

        {error && <div className="form-error">{error}</div>}

        {loading ? (
          <p>Loading users...</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <SortableHeader label="Name" field="name" sortBy={sortBy} order={order} onSort={handleSort} />
                <SortableHeader label="Email" field="email" sortBy={sortBy} order={order} onSort={handleSort} />
                <SortableHeader label="Address" field="address" sortBy={sortBy} order={order} onSort={handleSort} />
                <SortableHeader label="Role" field="role" sortBy={sortBy} order={order} onSort={handleSort} />
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td className="address-cell">{u.address}</td>
                  <td>
                    <span className={`role-badge role-${u.role.toLowerCase()}`}>{u.role.replace('_', ' ')}</span>
                  </td>
                  <td>
                    <button className="link-btn" onClick={() => handleViewDetails(u.id)}>
                      View
                    </button>
                  </td>
                </tr>
              ))}
              {users.length === 0 && (
                <tr>
                  <td colSpan={5} className="empty-row">
                    No users found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}

        {selectedUser && (
          <div className="modal-overlay" onClick={() => setSelectedUser(null)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <h3>User Details</h3>
              <p><strong>Name:</strong> {selectedUser.name}</p>
              <p><strong>Email:</strong> {selectedUser.email}</p>
              <p><strong>Address:</strong> {selectedUser.address}</p>
              <p><strong>Role:</strong> {selectedUser.role.replace('_', ' ')}</p>
              {selectedUser.role === 'STORE_OWNER' && (
                <p><strong>Store Rating:</strong> {selectedUser.storeRating} ({selectedUser.totalRatings} ratings)</p>
              )}
              <button onClick={() => setSelectedUser(null)}>Close</button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default AdminUsers;
