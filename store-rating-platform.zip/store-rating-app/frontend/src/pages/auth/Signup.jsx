import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/useAuth';

const initialForm = { name: '', email: '', address: '', password: '' };

// Mirrors backend validators.js exactly so the user gets instant feedback
// instead of waiting for a round trip to find out the password was too short.
const validateForm = (form) => {
  const errors = {};

  if (form.name.trim().length < 20 || form.name.trim().length > 60) {
    errors.name = 'Name must be between 20 and 60 characters.';
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
    errors.email = 'Please provide a valid email address.';
  }

  if (form.address.trim().length === 0 || form.address.trim().length > 400) {
    errors.address = 'Address is required and must be at most 400 characters.';
  }

  if (form.password.length < 8 || form.password.length > 16) {
    errors.password = 'Password must be between 8 and 16 characters.';
  } else if (!/[A-Z]/.test(form.password)) {
    errors.password = 'Password must contain at least one uppercase letter.';
  } else if (!/[!@#$%^&*(),.?":{}|<>_\-+=~`[\]\\/;']/.test(form.password)) {
    errors.password = 'Password must contain at least one special character.';
  }

  return errors;
};

const Signup = () => {
  const [form, setForm] = useState(initialForm);
  const [fieldErrors, setFieldErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { signup } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError('');

    const errors = validateForm(form);
    setFieldErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setSubmitting(true);
    try {
      await signup(form);
      navigate('/user/stores');
    } catch (err) {
      if (err.response?.data?.errors) {
        const backendErrors = {};
        err.response.data.errors.forEach((e) => {
          backendErrors[e.field] = e.message;
        });
        setFieldErrors(backendErrors);
      } else {
        setServerError(err.response?.data?.message || 'Signup failed. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-page">
      <form className="auth-form" onSubmit={handleSubmit}>
        <h1>Create Account</h1>
        <p className="auth-subtitle">Sign up as a Normal User</p>

        {serverError && <div className="form-error">{serverError}</div>}

        <label>
          Name
          <input type="text" name="name" value={form.name} onChange={handleChange} required />
          <span className="field-hint">20-60 characters</span>
          {fieldErrors.name && <span className="field-error">{fieldErrors.name}</span>}
        </label>

        <label>
          Email
          <input type="email" name="email" value={form.email} onChange={handleChange} required />
          {fieldErrors.email && <span className="field-error">{fieldErrors.email}</span>}
        </label>

        <label>
          Address
          <textarea name="address" value={form.address} onChange={handleChange} required maxLength={400} rows={3} />
          <span className="field-hint">{form.address.length}/400 characters</span>
          {fieldErrors.address && <span className="field-error">{fieldErrors.address}</span>}
        </label>

        <label>
          Password
          <input type="password" name="password" value={form.password} onChange={handleChange} required />
          <span className="field-hint">8-16 characters, 1 uppercase letter, 1 special character</span>
          {fieldErrors.password && <span className="field-error">{fieldErrors.password}</span>}
        </label>

        <button type="submit" disabled={submitting}>
          {submitting ? 'Creating account...' : 'Sign Up'}
        </button>

        <p className="auth-switch">
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </form>
    </div>
  );
};

export default Signup;
