import { useState, useEffect } from 'react';
import { getStoreOwnerDashboardApi } from '../../api/storeOwnerApi';
import Navbar from '../../components/Navbar';

const StoreOwnerDashboard = () => {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getStoreOwnerDashboardApi()
      .then((res) => setData(res.data.stores))
      .catch((err) => setError(err.response?.data?.message || 'Failed to load dashboard.'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <>
      <Navbar />
      <div className="page-container">
        <h1>Store Owner Dashboard</h1>

        {loading && <p>Loading...</p>}
        {error && <div className="form-error">{error}</div>}

        {data &&
          data.map(({ store, averageRating, totalRatings, raters }) => (
            <div key={store.id} className="card store-owner-card">
              <h2>{store.name}</h2>
              <p className="muted-text">{store.address}</p>

              <div className="stats-grid">
                <div className="stat-card">
                  <span className="stat-number">{averageRating > 0 ? `★ ${averageRating}` : '—'}</span>
                  <span className="stat-label">Average Rating</span>
                </div>
                <div className="stat-card">
                  <span className="stat-number">{totalRatings}</span>
                  <span className="stat-label">Total Ratings</span>
                </div>
              </div>

              <h3>Users Who Rated This Store</h3>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Rating</th>
                  </tr>
                </thead>
                <tbody>
                  {raters.map((r) => (
                    <tr key={r.user_id}>
                      <td>{r.name}</td>
                      <td>{r.email}</td>
                      <td>★ {r.rating}</td>
                    </tr>
                  ))}
                  {raters.length === 0 && (
                    <tr>
                      <td colSpan={3} className="empty-row">
                        No ratings submitted yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          ))}
      </div>
    </>
  );
};

export default StoreOwnerDashboard;
