import { useState, useEffect, useCallback } from 'react';
import { getStoresApi, submitRatingApi } from '../../api/userApi';
import Navbar from '../../components/Navbar';
import SortableHeader from '../../components/SortableHeader';
import StarRating from '../../components/StarRating';

const UserStores = () => {
  const [stores, setStores] = useState([]);
  const [search, setSearch] = useState({ name: '', address: '' });
  const [sortBy, setSortBy] = useState('name');
  const [order, setOrder] = useState('asc');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [savingStoreId, setSavingStoreId] = useState(null);
  const [toast, setToast] = useState('');

  const fetchStores = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = { ...search, sortBy, order };
      Object.keys(params).forEach((k) => params[k] === '' && delete params[k]);
      const res = await getStoresApi(params);
      setStores(res.data.stores);
    } catch {
      setError('Failed to load stores.');
    } finally {
      setLoading(false);
    }
  }, [search, sortBy, order]);

  useEffect(() => {
    fetchStores();
  }, [fetchStores]);

  const handleSearchChange = (e) => {
    setSearch({ ...search, [e.target.name]: e.target.value });
  };

  const handleSort = (field, newOrder) => {
    setSortBy(field);
    setOrder(newOrder);
  };

  const handleRate = async (storeId, rating) => {
    setSavingStoreId(storeId);
    try {
      await submitRatingApi(storeId, rating);
      setStores((prev) =>
        prev.map((s) => (s.id === storeId ? { ...s, user_rating: rating } : s))
      );
      // Refresh so the overall average reflects the new/updated rating too
      fetchStores();
      setToast('Rating saved.');
      setTimeout(() => setToast(''), 2000);
    } catch {
      setError('Failed to submit rating. Please try again.');
    } finally {
      setSavingStoreId(null);
    }
  };

  return (
    <>
      <Navbar />
      <div className="page-container">
        <h1>Browse Stores</h1>

        <div className="filters-row">
          <input name="name" placeholder="Search by Store Name" value={search.name} onChange={handleSearchChange} />
          <input name="address" placeholder="Search by Address" value={search.address} onChange={handleSearchChange} />
        </div>

        {toast && <div className="form-success">{toast}</div>}
        {error && <div className="form-error">{error}</div>}

        {loading ? (
          <p>Loading stores...</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <SortableHeader label="Store Name" field="name" sortBy={sortBy} order={order} onSort={handleSort} />
                <SortableHeader label="Address" field="address" sortBy={sortBy} order={order} onSort={handleSort} />
                <SortableHeader label="Overall Rating" field="overall_rating" sortBy={sortBy} order={order} onSort={handleSort} />
                <th>Your Rating</th>
              </tr>
            </thead>
            <tbody>
              {stores.map((s) => (
                <tr key={s.id}>
                  <td>{s.name}</td>
                  <td className="address-cell">{s.address}</td>
                  <td>
                    {s.overall_rating > 0 ? `★ ${s.overall_rating}` : 'No ratings yet'}{' '}
                    <span className="muted-text">({s.total_ratings})</span>
                  </td>
                  <td>
                    <StarRating
                      value={s.user_rating}
                      disabled={savingStoreId === s.id}
                      onChange={(rating) => handleRate(s.id, rating)}
                    />
                    {s.user_rating && <span className="muted-text rate-hint">Click a star to change it</span>}
                  </td>
                </tr>
              ))}
              {stores.length === 0 && (
                <tr>
                  <td colSpan={4} className="empty-row">
                    No stores found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
};

export default UserStores;
